import { Component, OnInit, ViewChild } from '@angular/core';
import { GooglePlaceDirective } from 'ngx-google-places-autocomplete';
import { Address } from 'ngx-google-places-autocomplete/objects/address';

import {HttpClient,HttpHeaders} from '@angular/common/http'
import { Router, ActivatedRoute, Params } from '@angular/router';

// import { IDropdownSettings } from 'ng-multiselect-dropdown';

export class FormInput {
  
  firstname : any
  lastname : any
  fathername: any
 
  emailId : any 
  country : any
 
  address : any

  phoneNo: any
  
  birthday_date:any;
  male:any;
  famale:any;
}

@Component({
  selector: 'app-add-event',
  templateUrl: './add-event.component.html',
  styleUrls: ['./add-event.component.scss']
})



export class AddEventComponent implements OnInit {
formInput: FormInput;
  public isSubmit: boolean;
  evenetData: any = [];

  evenetData_new: any = [];

  id: any;



    ordersData:any;



  constructor(private router: Router,private activatedRoute: ActivatedRoute,private http: HttpClient) {

    
    this.activatedRoute.params.subscribe((params: Params) => {
      this.id = params['id'];
      if(localStorage.getItem("eventData")){
        this.evenetData_new = JSON.parse (localStorage.getItem("eventData"));
      } 

     


    
    });
 
    this.ordersData = [
      { id: 1, name: 'India' },
      { id: 2, name: 'Afghanistan' },
      { id: 3, name: 'Albania' },
      { id: 4, name: 'Armenia' },
      { id: 5, name: 'Algeria' },
      { id: 6, name: 'Andorra' },
      { id: 7, name: 'Angola' },
      { id: 8, name: 'Armenia' },
      { id: 10, name: 'Argentina' }
     
    ];

 }

  ngOnInit(): void {


    this.formInput = {
  
     firstname : '',
      country : '',
      fathername: '',
      lastname:'',
      emailId:'',
      phoneNo: '',
      birthday_date:'' ,
      address:'' ,
      male:false ,
      famale:false 
  };

  if(this.id != undefined)
  {
  for (let i = 0; i < this.evenetData_new.length; i++) {

    if(i == this.id)
    {

this.formInput.firstname = this.evenetData_new[i].firstname
this.formInput.lastname = this.evenetData_new[i].lastname
this.formInput.fathername  =this.evenetData_new[i].fathername
this.formInput.country = this.evenetData_new[i].country  
 this.formInput.emailId = this.evenetData_new[i].emailId
  this.formInput.phoneNo = this.evenetData_new[i].phoneNo
 this.formInput.address = this.evenetData_new[i].address
this.formInput.birthday_date =  this.evenetData_new[i].birthday_date
this.formInput.male =  this.evenetData_new[i].male


    }

  }
  }
    
  }

  Submit(form:any){
    if(!form.valid){
      this.isSubmit = true;
      return;
    }
    if(localStorage.getItem("eventData")){
      this.evenetData = JSON.parse (localStorage.getItem("eventData"));
    }  

    
        
    this.evenetData.push({    
    firstname: this.formInput.firstname, 
    lastname: this.formInput.lastname, 
    fathername: this.formInput.fathername, 
    country: this.formInput.country,    
    emailId: this.formInput.emailId, 
    phoneNo: this.formInput.phoneNo, 
    address: this.formInput.address, 
    birthday_date: this.formInput.birthday_date, 
    male: this.formInput.male
  
    
     });



    
     console.log('==========================  Events Data =====================================')
     console.log('')
     console.log('',this.evenetData)
     console.log('')
     console.log('===============================================================')


     localStorage.setItem("eventData" , JSON.stringify(this.evenetData));
     if(localStorage.getItem("eventData")){
      this.evenetData = JSON.parse (localStorage.getItem("eventData"));
    } 
    if(this.id != undefined)
    {
      
      var index = this.evenetData.indexOf(this.id);
      this.evenetData.splice(index, 1);
      localStorage.setItem("eventData" , JSON.stringify(this.evenetData));

     }
      // this.evenetData.push(JSON.parse(JSON.stringify(this.formInput)));  
      // localStorage.setItem("eventData" , JSON.stringify(this.evenetData));
      this.formInput = new FormInput();    

      this.router.navigate(['/']);
  }    


Cancel()
{
  this.router.navigate(['/']);
}

}