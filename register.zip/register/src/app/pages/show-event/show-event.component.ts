import { Component, OnInit } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import { Router, ActivatedRoute, Params } from '@angular/router';



@Component({
  selector: 'app-show-event',
  templateUrl: './show-event.component.html',
  styleUrls: ['./show-event.component.scss']
})
export class ShowEventComponent implements OnInit {

  data: any;
  orders :any;
  evenetData : any = [];


  constructor(private http: HttpClient,private router: Router,private activatedRoute: ActivatedRoute) { 
  }

  ngOnInit(): void {

    this.evenetData = JSON.parse(localStorage.getItem("eventData"));
  
  }

  deleteRecord(id){
  
    console.log("id-----",id)
    this.evenetData.splice(id,1);
    localStorage.setItem("eventData" , JSON.stringify(this.evenetData));

    
  }

  update(i)
  {
    alert(i)
  }

  getOrders() {
    const prodlist = 'http://173.212.252.61:8989/station/getAll'

     this.http.get(prodlist,{
      headers : new HttpHeaders({
        'Content-Type':'application/json'
        
      })  }).subscribe(data=>{
  
      
        console.log(data);
        this.orders = data['result'];
    
  })
  }

  deleteGeofence(station_id)
    {
    
      const body = JSON.stringify( {"station_id":station_id})

      const options = {
        headers: new HttpHeaders({
          'Content-Type':'application/json'
                }),
        body
      }
        const deleteGeofence = 'http://173.212.252.61:8989/station/delete';
         this.http.delete(deleteGeofence ,options).subscribe(data=>{
  
        this.getOrders();
      
    })
        
    }

}
