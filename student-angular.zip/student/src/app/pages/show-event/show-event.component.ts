import { Component, OnInit } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import { Router, ActivatedRoute, Params } from '@angular/router';



@Component({
  selector: 'app-show-event',
  templateUrl: './show-event.component.html',
  styleUrls: ['./show-event.component.scss']
})
export class ShowEventComponent implements OnInit {

  data: any;
  student :any;


  constructor(private http: HttpClient,private router: Router,private activatedRoute: ActivatedRoute) { 
  }

  ngOnInit(): void {

    this.getStudent();  
  }


  update(i)
  {
    alert(i)
  }

  getStudent() {
    const prodlist = 'http://localhost:8081/getAllStudentInfo'

     this.http.get(prodlist,{
      headers : new HttpHeaders({
        'Content-Type':'application/json'
        
      })  }).subscribe(data=>{
  
      
        console.log(data);
        this.student = data;
    
  })
  }

  deleteStudent(student_id)
    {
    
      const options = {
        headers: new HttpHeaders({
          'Content-Type':'application/json'
                }),
      
      }
        const deletestudent = 'http://localhost:8081/deleteBy/'+student_id;
         this.http.get(deletestudent ,options).subscribe(data=>{
  
        this.getStudent();
      
    })
    
    }


    


    updateStudent(studentData){
      localStorage.setItem('id',studentData.id)

      localStorage.setItem('studentName',studentData.studentName)
      localStorage.setItem('maths',studentData.maths)
      localStorage.setItem('physics',studentData.physics)
      localStorage.setItem('chemistry',studentData.chemistry)
      localStorage.setItem('total',studentData.total)

      localStorage.setItem('percentage',studentData.percentage)


      this.router.navigate(['/addevent/', studentData.id]);


    }

}
