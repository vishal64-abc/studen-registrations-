import { Component, OnInit, ViewChild } from '@angular/core';
import { GooglePlaceDirective } from 'ngx-google-places-autocomplete';
import { Address } from 'ngx-google-places-autocomplete/objects/address';

import {HttpClient,HttpHeaders} from '@angular/common/http'
import { Router, ActivatedRoute, Params } from '@angular/router';

// import { IDropdownSettings } from 'ng-multiselect-dropdown';

export class FormInput {
  id:any;
  studentName : any
  physics : number
  chemistry: number
 
  maths : number 
  total:number
  percentage:number
  
}

@Component({
  selector: 'app-add-event',
  templateUrl: './add-event.component.html',
  styleUrls: ['./add-event.component.scss']
})



export class AddEventComponent implements OnInit {
formInput: FormInput;
  public isSubmit: boolean;
 
  total : any;
  percentage:any;


  id: any;






  constructor(private router: Router,private activatedRoute: ActivatedRoute,private http: HttpClient) {

    
    this.activatedRoute.params.subscribe((params: Params) => {
      this.id = params['id'];
     

     


    
    });
 
  

 }

  ngOnInit(): void {

    if(this.id > 0)
    {
     this.formInput.studentName =  localStorage.getItem("studentName");
     this.formInput.maths = Number(localStorage.getItem("maths"));

     this.formInput.physics =  Number(localStorage.getItem("physics"));
     this.formInput.chemistry = Number( localStorage.getItem("chemistry"));
     this.formInput.total =  Number(localStorage.getItem("total"));
     this.formInput.percentage = Number( localStorage.getItem("percentage"));


    }else{



      this.formInput = {
       id :0,
        studentName : '',
       
        physics : 0,
        chemistry: 0,
   
        maths : 0,
        percentage:0,
        total:0
      
    };
    }


  
    
  }

  
  Submit(form:any){
    if(!form.valid){
      this.isSubmit = true;
      return;
    }

    if(this.id > 0 )
{

  this.formInput.id = this.id;
  const students = 'http://localhost:8081/updateStudent'
     this.http.put(students,JSON.stringify(this.formInput),{
       headers : new HttpHeaders({
         'Content-Type':'application/json'
         
       },
       )  }).subscribe(data=>{
 
        console.log("data----",data)
   })
  
}else{
    console.log(JSON.stringify(this.formInput))

    const students = 'http://localhost:8081/addStudentInfo'
     this.http.post(students,JSON.stringify(this.formInput),{
       headers : new HttpHeaders({
         'Content-Type':'application/json'
         
       })  }).subscribe(data=>{
 
        console.log("data----",data)
   })
  }
      this.router.navigate(['/']);
  }    


Cancel()
{
  this.router.navigate(['/']);
}


totalCalculate()
{
  this.formInput.total = 0;

  var  totalmarks = 0;

  totalmarks = Number(this.formInput.maths) + Number(this.formInput.chemistry) + Number(this.formInput.physics);

  this.formInput.percentage = ( totalmarks / 300) * 100;

   this.formInput.total = totalmarks;

   console.log( this.formInput.percentage)

  this.total = this.formInput.total;
  this.percentage = this.formInput.percentage;
}

}