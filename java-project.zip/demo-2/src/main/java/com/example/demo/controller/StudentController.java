package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.StudentInfo;
import com.example.demo.service.StudentService;

@RestController
@CrossOrigin
public class StudentController {

	@Autowired
	private StudentService studentService;
	
	@PostMapping(value="/addStudentInfo")
	public ResponseEntity<?> addStudentInfo(@RequestBody StudentInfo studentInfo) {
		StudentInfo info = studentService.addStundentInfo(studentInfo);
		return ResponseEntity.ok(info);
	}
	
	@GetMapping(value = "/getBy/{id}")
	public ResponseEntity<?> getStudentById(@PathVariable long id) throws Exception{
		StudentInfo studentInfo = studentService.getById(id);
		return ResponseEntity.ok(studentInfo);
	}
	
	@GetMapping(value = "/deleteBy/{id}")
	public ResponseEntity<?> deleteStudentById(@PathVariable long id) throws Exception{
		studentService.getById(id);
		studentService.deleteById(id);
		String message = "Student Successfully deleted.";
		return ResponseEntity.ok(message);
	}
	
	@PutMapping(value="/updateStudent")
	public ResponseEntity<?> updateStudentInfo(@RequestBody StudentInfo studentInfo) throws Exception {
		studentService.getById(studentInfo.getId());
		StudentInfo info = studentService.updateStundentInfo(studentInfo);
		return ResponseEntity.ok(info);
	}
	
	@GetMapping(value = "/getAllStudentInfo")
	public ResponseEntity<?> getAllStudentInfo(){
		List<StudentInfo> studentInfo = studentService.getAllStudent();
		return ResponseEntity.ok(studentInfo);
	}
}
