package com.example.demo.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Strund_info_tab")
public class StudentInfo {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	private String studentName;
	private Integer maths;
	private Integer physics;
	private Integer chemistry;
	private Integer total;
	private Float percentage;
	
	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * @return the studentName
	 */
	public String getStudentName() {
		return studentName;
	}
	/**
	 * @param studentName the studentName to set
	 */
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	/**
	 * @return the maths
	 */
	public Integer getMaths() {
		return maths;
	}
	/**
	 * @param maths the maths to set
	 */
	public void setMaths(Integer maths) {
		this.maths = maths;
	}
	/**
	 * @return the physics
	 */
	public Integer getPhysics() {
		return physics;
	}
	/**
	 * @param physics the physics to set
	 */
	public void setPhysics(Integer physics) {
		this.physics = physics;
	}
	/**
	 * @return the chemistry
	 */
	public Integer getChemistry() {
		return chemistry;
	}
	/**
	 * @param chemistry the chemistry to set
	 */
	public void setChemistry(Integer chemistry) {
		this.chemistry = chemistry;
	}
	/**
	 * @return the total
	 */
	public Integer getTotal() {
		return total;
	}
	/**
	 * @param total the total to set
	 */
	public void setTotal(Integer total) {
		this.total = total;
	}
	/**
	 * @return the percentage
	 */
	public float getPercentage() {
		return percentage;
	}
	/**
	 * @param percentage the percentage to set
	 */
	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}
	
	
	
}
