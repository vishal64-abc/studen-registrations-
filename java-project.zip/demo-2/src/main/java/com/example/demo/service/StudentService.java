package com.example.demo.service;

import java.util.List;

import com.example.demo.model.StudentInfo;

public interface StudentService {

	StudentInfo addStundentInfo(StudentInfo strudentInfo);

	StudentInfo getById(Long id) throws Exception;

	void deleteById(Long id);

	StudentInfo updateStundentInfo(StudentInfo studentInfo);

	List<StudentInfo> getAllStudent();

}
