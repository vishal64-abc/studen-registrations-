package com.example.demo.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Repository.StudentRepository;
import com.example.demo.model.StudentInfo;
import com.example.demo.service.StudentService;

@Service
public class StrudentServiceImpl implements StudentService {

	@Autowired
	private StudentRepository studentRepository;
	
	@Override
	public StudentInfo addStundentInfo(StudentInfo studentInfo) {
		return studentRepository.save(studentInfo);
	}

	@Override
	public StudentInfo getById(Long id) throws Exception {
		Optional<StudentInfo> studentInfoOptinal = studentRepository.findById(id);
		StudentInfo studentInfo = studentInfoOptinal.orElseThrow(() -> new Exception("Student not found."));
		return studentInfo;
	}

	@Override
	public void deleteById(Long id) {
		studentRepository.deleteById(id);
	}

	@Override
	public StudentInfo updateStundentInfo(StudentInfo studentInfo) {
		return studentRepository.save(studentInfo);
	}

	@Override
	public List<StudentInfo> getAllStudent() {
		return studentRepository.findAll();
	}

}
